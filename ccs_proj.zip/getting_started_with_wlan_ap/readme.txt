For information on this example refer to:
docs\examples\CC32xx Getting Started with WLAN AP.pdf
or
http://processors.wiki.ti.com/index.php/CC32xx_Getting_Started_with_WLAN_AP